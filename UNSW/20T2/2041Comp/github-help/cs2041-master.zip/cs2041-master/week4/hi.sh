#!/bin/bash

hi
hi
hi
hi
hi
