#!/usr/bin/python

answer = 6 * 7
print answer
answer = answer / 7
print answer
answer = answer + 1 + 7 * 7 - 8;
print answer
print answer * answer
answer = answer ** 2
print answer
answer = answer % 4
print answer

