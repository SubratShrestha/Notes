#!/usr/bin/perl -w
$factor0 = 6;
$factor1 = 7;
print $factor0 * $factor1, "\n";
