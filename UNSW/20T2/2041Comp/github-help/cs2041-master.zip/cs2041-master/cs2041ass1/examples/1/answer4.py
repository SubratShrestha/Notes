#!/usr/bin/python

factor0 = 6
factor1 = 7
print factor0 * factor1
