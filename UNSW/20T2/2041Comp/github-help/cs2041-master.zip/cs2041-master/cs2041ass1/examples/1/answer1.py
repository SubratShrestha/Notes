#!/usr/bin/python

answer = 6 * 7
print answer