#!/usr/bin/python

answer = 0
while (answer < 36): answer = answer + 7
if answer > 0:
    answer = answer + 2
if answer == 42:
    answer = answer - 1
else:
	answer = answer + 1
print answer