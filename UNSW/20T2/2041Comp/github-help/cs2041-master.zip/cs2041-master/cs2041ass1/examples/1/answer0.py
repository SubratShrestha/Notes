#!/usr/bin/python

answer = 6 * 7
print answer
answer = answer / 7
print answer
answer = answer + 1 + 7 * 7 - 8;
print answer