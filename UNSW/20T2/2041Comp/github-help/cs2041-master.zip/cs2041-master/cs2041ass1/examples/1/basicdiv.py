#!/usr/bin/python

factor0 = 84
factor1 = 2
print factor0 / factor1