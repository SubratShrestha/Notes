#!/usr/bin/python

#Adapted from answer5.py

answer = 41
if answer > 0: answer = answer + 2
if answer >= 41: answer = answer + 2
if answer < 43: answer = answer + 2
if answer <= 41: answer = answer + 2
if answer == 49: answer = answer - 1
if answer != 49: answer = answer + 1
if answer <> 50: answer = answer + 1
print answer
