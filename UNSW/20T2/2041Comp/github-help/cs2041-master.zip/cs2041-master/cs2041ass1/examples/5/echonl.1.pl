#!/usr/bin/perl -w

foreach $i (1..@ARGV) {
	print "$ARGV[$i-1]\n";
}
