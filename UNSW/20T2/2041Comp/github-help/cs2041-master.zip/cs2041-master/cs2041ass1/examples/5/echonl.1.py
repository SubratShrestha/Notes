#!/usr/bin/python
import sys
for i in range(1,len(sys.argv)):
		print sys.argv[i]
