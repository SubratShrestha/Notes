#!/usr/bin/python

factor0 = 10
factor1 = 2
print factor0 ** factor1