#!/usr/bin/python

aList = [123, 'xyz', 'zara', 'abc', 456, 'asd', 'afd', 'adg'];

print len(aList);
print "A List : ", aList.pop();
print "B List : ", aList.pop(1);
print "C List : ", aList.pop((3));
print "D List : ", aList.pop((5)-1);
print "E List : ", "HAHA";
