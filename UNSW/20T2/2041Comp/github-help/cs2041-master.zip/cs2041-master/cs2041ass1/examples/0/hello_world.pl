#!/usr/bin/perl -w
print "hello world", "\n";
