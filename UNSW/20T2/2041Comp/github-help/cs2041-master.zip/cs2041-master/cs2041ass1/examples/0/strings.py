#!/usr/bin/python

str = 'Hello World!'

print str          # Prints complete string
#print str * 2      # Prints string two times
print str + "TEST" # Prints concatenated string