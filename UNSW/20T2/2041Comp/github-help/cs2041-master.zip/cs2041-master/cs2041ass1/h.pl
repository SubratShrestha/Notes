#!/usr/bin/perl -w

$counter = 100          ;# An integer assignment;
$miles   = 1000.0       ;# A floating point;
$miles2   = 1000.1       ;# A floating point;
$name    = "John"       ;# A string;

print $counter, "\n";
print "counter\n";
print $miles, "\n";
print 'miles', "\n";
print $miles2, "\n";
print $name, "\n";
