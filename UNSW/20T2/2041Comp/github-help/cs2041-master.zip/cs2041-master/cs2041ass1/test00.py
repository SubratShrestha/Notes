#!/usr/bin/python

str = 'Hello World!'

print str          # Prints complete string
print str * 2      # Prints string two times
print str + "TEST" # Prints concatenated string
print "TEST1" + "TEST2" # Prints concatenated string
print str + str;
print 'str'
print "str"
print 'Hello'
print "Hello"
print "Hello World"
print 'Hello World'
print "Hello \" World"
print "Hello \\\" World"
