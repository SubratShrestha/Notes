#include <stdio.h>


int main () {

	printf("%d\n", 10192%4096 + 4096*6);

return 0;
}
