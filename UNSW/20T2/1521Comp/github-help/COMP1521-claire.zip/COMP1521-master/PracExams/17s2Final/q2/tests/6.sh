./q2 tests/p6.dat
