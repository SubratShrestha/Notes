./q2 tests/p4.dat
