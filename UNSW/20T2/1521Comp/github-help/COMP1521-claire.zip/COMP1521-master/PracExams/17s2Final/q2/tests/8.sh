./q2 tests/p8.dat
