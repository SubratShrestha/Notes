./q2 tests/p1.dat
