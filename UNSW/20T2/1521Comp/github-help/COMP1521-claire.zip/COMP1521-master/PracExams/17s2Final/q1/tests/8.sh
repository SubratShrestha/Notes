exe tests/a8.s
