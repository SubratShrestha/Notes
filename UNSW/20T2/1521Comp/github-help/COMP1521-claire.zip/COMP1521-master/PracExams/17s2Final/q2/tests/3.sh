./q2 tests/p3.dat
