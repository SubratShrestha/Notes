./q3 5 < tests/jobs4
