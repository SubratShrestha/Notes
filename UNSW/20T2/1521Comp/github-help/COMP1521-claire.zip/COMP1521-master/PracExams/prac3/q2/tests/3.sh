./stu 88.0 tests/s1.dat
