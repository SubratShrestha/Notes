exe tests/s8.s
