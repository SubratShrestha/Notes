./stu 61.0 tests/s2.dat
