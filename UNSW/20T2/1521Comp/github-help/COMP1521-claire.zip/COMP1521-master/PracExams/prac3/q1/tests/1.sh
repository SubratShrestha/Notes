exe tests/s1.s
