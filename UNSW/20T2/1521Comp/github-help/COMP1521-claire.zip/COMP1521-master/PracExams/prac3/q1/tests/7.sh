exe tests/s7.s
