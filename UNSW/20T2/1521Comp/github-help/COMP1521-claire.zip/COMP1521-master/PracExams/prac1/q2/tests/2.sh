./stu tests/s2.dat
