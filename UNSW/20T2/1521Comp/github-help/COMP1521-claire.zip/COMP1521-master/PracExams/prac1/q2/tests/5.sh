./stu tests/s5.dat
