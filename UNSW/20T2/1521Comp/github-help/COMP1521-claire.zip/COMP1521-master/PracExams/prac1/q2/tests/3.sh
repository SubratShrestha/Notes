./stu tests/s3.dat
