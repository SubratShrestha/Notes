./vmsim 8 2 < tests/trace04
