./vmsim 4 3 < tests/trace01
