./vmsim 5 3 < tests/trace04
