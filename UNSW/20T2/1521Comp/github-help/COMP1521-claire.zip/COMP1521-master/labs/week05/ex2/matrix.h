// COMP1521 18s2 ... lab 5 matrix data

#define N 3

int m[N][N] =
  {
    { 1, 0, 0 },
    { 0, 1, 0 },
    { 0, 0, 1 }
  };
