echo 12 | ~cs1521/bin/spim -file fac.s | sed -n -e '$s/n  = //p'
