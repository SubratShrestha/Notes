#include <stdio.h>

#define TRUE 1
#define FALSE 0


int main () {
    int a = TRUE;
    
    int b = FALSE;
    
    if (a == TRUE) {
        printf("a");
    }


    return 0;
}
