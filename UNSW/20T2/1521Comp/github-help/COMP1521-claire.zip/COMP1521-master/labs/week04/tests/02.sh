echo 12 | /home/cs1521/bin/spim -file fac1.s | sed -e '1d;s/n  = //'
