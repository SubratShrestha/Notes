echo hello | /home/cs1521/bin/spim -file fac2.s | sed -e '1d;s/n  = //'
