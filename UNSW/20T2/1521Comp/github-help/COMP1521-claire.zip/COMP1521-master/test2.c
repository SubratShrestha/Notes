#include <stdio.h>

int main() {

	int n, a, b, c;
	n = scanf("%d %d %d", &a, &b, &c);
	
	printf("n is %d and %d %d %d\n", n, a, b, c);

return 0;
}
