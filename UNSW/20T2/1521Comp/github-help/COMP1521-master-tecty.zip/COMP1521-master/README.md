# COMP1521
A repo of lab exercise of COMP 1521. DON'T COPY IT DIRECTLY. 
