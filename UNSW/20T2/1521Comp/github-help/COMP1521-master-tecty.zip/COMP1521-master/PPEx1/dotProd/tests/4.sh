~cs1521/bin/exe tests/a4.s
