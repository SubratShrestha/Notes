~cs1521/bin/exe tests/a3.s
