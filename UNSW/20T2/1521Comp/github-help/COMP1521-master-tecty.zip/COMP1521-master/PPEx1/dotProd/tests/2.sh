~cs1521/bin/exe tests/a2.s
