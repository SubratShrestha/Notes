~cs1521/bin/exe tests/a8.s
