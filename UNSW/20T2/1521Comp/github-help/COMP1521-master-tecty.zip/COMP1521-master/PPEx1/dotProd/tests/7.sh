~cs1521/bin/exe tests/a7.s
