~cs1521/bin/exe tests/a5.s
