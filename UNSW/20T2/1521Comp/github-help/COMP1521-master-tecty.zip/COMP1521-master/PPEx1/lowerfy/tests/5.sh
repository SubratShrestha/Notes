~cs1521/bin/exe tests/s5.s
