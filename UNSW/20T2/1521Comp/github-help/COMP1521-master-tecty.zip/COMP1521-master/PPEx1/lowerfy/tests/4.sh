~cs1521/bin/exe tests/s4.s
