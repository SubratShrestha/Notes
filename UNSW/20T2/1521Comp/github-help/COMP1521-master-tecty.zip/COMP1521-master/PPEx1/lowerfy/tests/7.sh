~cs1521/bin/exe tests/s7.s
