~cs1521/bin/exe tests/s1.s
