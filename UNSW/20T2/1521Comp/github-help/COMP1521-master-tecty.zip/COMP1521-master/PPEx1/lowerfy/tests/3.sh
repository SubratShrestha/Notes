~cs1521/bin/exe tests/s3.s
