~cs1521/bin/exe tests/s8.s
