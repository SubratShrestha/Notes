~cs1521/bin/exe tests/s6.s
