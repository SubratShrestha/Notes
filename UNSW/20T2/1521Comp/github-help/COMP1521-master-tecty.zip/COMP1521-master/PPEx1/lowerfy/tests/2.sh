~cs1521/bin/exe tests/s2.s
